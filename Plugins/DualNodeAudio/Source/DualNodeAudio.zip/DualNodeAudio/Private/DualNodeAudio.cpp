#include "DualNodeAudio.h"
#define LOCTEXT_NAMESPACE "FDualNodeAudioModule"
void FDualNodeAudioModule::StartupModule() {}
void FDualNodeAudioModule::ShutdownModule() {}
#undef LOCTEXT_NAMESPACE
IMPLEMENT_MODULE(FDualNodeAudioModule, DualNodeAudio)